require_relative "scraper"

Scraper.scrape!
